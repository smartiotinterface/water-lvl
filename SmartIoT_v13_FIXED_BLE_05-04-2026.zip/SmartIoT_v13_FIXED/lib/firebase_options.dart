// lib/firebase_options.dart
// ──────────────────────────────────────────────────────────────────────────────
// ⚠️  SECURITY WARNING: এই ফাইলটি .gitignore-এ আছে।
//    এখানে REAL credentials রাখবেন না।
//    নিচের command দিয়ে আপনার নিজের credentials generate করুন:
//
//    dart pub global activate flutterfire_cli
//    flutterfire configure --project=YOUR_PROJECT_ID
//
// ──────────────────────────────────────────────────────────────────────────────

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return web;
      case TargetPlatform.linux:
        throw UnsupportedError('Linux not configured. Run: flutterfire configure');
      default:
        throw UnsupportedError('Unsupported platform.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB2-liVlbm41MET6Oyepu6WrZfy2qA7B-k',
    appId: '1:353683838193:android:a9fa82f1e6dc721b4bc550',
    messagingSenderId: '353683838193',
    projectId: 'smartiot-8190a',
    databaseURL: 'https://smartiot-8190a-default-rtdb.firebaseio.com',
    storageBucket: 'smartiot-8190a.firebasestorage.app',
  );

  // ── Replace YOUR_ values after running: flutterfire configure ──────────────

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDQ8jM-8-ftiIp308RRq7lwT7PhQD01U0U',
    appId: '1:353683838193:web:c23438501b5e4e994bc550',
    messagingSenderId: '353683838193',
    projectId: 'smartiot-8190a',
    authDomain: 'smartiot-8190a.firebaseapp.com',
    databaseURL: 'https://smartiot-8190a-default-rtdb.firebaseio.com',
    storageBucket: 'smartiot-8190a.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDbFpvUwNQOgGwasXeBIH_jeQEDiyTREcI',
    appId: '1:353683838193:ios:60e3c91ca6bfed614bc550',
    messagingSenderId: '353683838193',
    projectId: 'smartiot-8190a',
    databaseURL: 'https://smartiot-8190a-default-rtdb.firebaseio.com',
    storageBucket: 'smartiot-8190a.firebasestorage.app',
    iosClientId: '353683838193-sabb2k98gop9aiu1mj14hv27ms7spkth.apps.googleusercontent.com',
    iosBundleId: 'com.smartiot.smartIotInterface',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyDbFpvUwNQOgGwasXeBIH_jeQEDiyTREcI',
    appId: '1:353683838193:ios:60e3c91ca6bfed614bc550',
    messagingSenderId: '353683838193',
    projectId: 'smartiot-8190a',
    databaseURL: 'https://smartiot-8190a-default-rtdb.firebaseio.com',
    storageBucket: 'smartiot-8190a.firebasestorage.app',
    iosClientId: '353683838193-sabb2k98gop9aiu1mj14hv27ms7spkth.apps.googleusercontent.com',
    iosBundleId: 'com.smartiot.smartIotInterface',
  );

}