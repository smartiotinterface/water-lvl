// lib/services/notification_service.dart
// Push notification handling via firebase_messaging + flutter_local_notifications

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';
import '../core/secure_storage.dart';

// Top-level handler required by Firebase (must be outside any class)
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint('[FCM] Background message: ${message.messageId}');
}

class NotificationService {
  NotificationService._();

  static final _messaging = FirebaseMessaging.instance;
  static final _localNotif = FlutterLocalNotificationsPlugin();

  static const _channelId   = 'smartiot_alerts';
  static const _channelName = 'SmartIoT Alerts';
  static const _channelDesc = 'Water tank level and pump alerts';

  // ── Init ─────────────────────────────────────────────────────────────
  static Future<void> init() async {
    // Register background handler
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

    // Request permission (iOS / Android 13+)
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    debugPrint('[FCM] Permission: ${settings.authorizationStatus}');

    // Configure local notifications channel (Android)
    const androidChannel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: _channelDesc,
      importance: Importance.high,
      playSound: true,
    );

    final androidPlugin =
        _localNotif.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(androidChannel);

    // Initialize local notifications
    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    );
    await _localNotif.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    // Save FCM token securely
    final token = await _messaging.getToken();
    if (token != null) {
      await SecureStorage.setFcmToken(token);
      debugPrint('[FCM] Token saved (${token.length} chars)');
    }

    // Handle token refresh
    _messaging.onTokenRefresh.listen((newToken) async {
      await SecureStorage.setFcmToken(newToken);
    });

    // Foreground message handler
    FirebaseMessaging.onMessage.listen(_handleForeground);
  }

  // ── Handlers ──────────────────────────────────────────────────────────
  static void _handleForeground(RemoteMessage message) {
    final notif = message.notification;
    if (notif == null) return;

    _localNotif.show(
      message.hashCode,
      notif.title ?? 'SmartIoT Alert',
      notif.body ?? '',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDesc,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  static void _onNotificationTap(NotificationResponse response) {
    debugPrint('[FCM] Notification tapped: ${response.payload}');
    // Navigate to relevant screen if needed
  }

  // ── Helpers ───────────────────────────────────────────────────────────
  static Future<String?> getToken() => SecureStorage.getFcmToken();

  /// Show a local alert immediately (for offline/foreground use)
  static Future<void> showLocalAlert({
    required String title,
    required String body,
  }) async {
    await _localNotif.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          importance: Importance.high,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
    );
  }
}
