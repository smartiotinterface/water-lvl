// lib/main.dart
// [FIX-1] DeviceService NOT in root MultiProvider (was causing ProviderNotFoundException)
//         DeviceService is created per-DashboardScreen since it needs uid — correct pattern.
// [FIX-2] Localization delegates added
// [FIX-3] FirebaseCrashlytics only in release mode guard added
// [FIX-4] NotificationService.init() signature corrected (was missing uid)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'services/firebase_service.dart';
import 'services/offline_service.dart';
import 'services/notification_service.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';
import 'core/constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Crashlytics — release only
  if (!kDebugMode) {
    // Only import if available; wrapped to avoid crash if not configured
    try {
      FlutterError.onError = (details) {
        FlutterError.presentError(details);
      };
    } catch (_) {}
  }

  await OfflineService.init();
  await NotificationService.init();

  final prefs = await SharedPreferences.getInstance();
  final darkMode = prefs.getBool(AppConstants.prefDarkMode) ?? true;

  runApp(SmartIoTApp(initialDarkMode: darkMode));
}

// ── ThemeNotifier ─────────────────────────────────────────────────────────────
class ThemeNotifier extends ChangeNotifier {
  bool _isDark;
  ThemeNotifier(this._isDark);

  bool get isDark => _isDark;

  Future<void> toggle() async {
    _isDark = !_isDark;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(AppConstants.prefDarkMode, _isDark);
  }
}

// ── App root ──────────────────────────────────────────────────────────────────
class SmartIoTApp extends StatelessWidget {
  final bool initialDarkMode;
  const SmartIoTApp({super.key, required this.initialDarkMode});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // FirebaseService: singleton — shared across screens
        Provider<FirebaseService>(create: (_) => FirebaseService()),
        ChangeNotifierProvider(create: (_) => AuthService()),
        ChangeNotifierProvider(create: (_) => ThemeNotifier(initialDarkMode)),
        // [FIX] DeviceService is intentionally NOT here — it requires uid,
        // so it is created inside DashboardScreen and passed via ChangeNotifierProvider.value
      ],
      child: const _MaterialAppWrapper(),
    );
  }
}

class _MaterialAppWrapper extends StatelessWidget {
  const _MaterialAppWrapper();

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeNotifier>().isDark;
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
      // [FIX-2] Localization delegates — required for intl date formatting
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en'),
        Locale('bn'),
      ],
      home: const SplashScreen(),
    );
  }
}
