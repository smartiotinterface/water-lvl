/**********************************************************************************
 * secrets.h — SmartIoT v13 Firmware Secrets
 * ──────────────────────────────────────────────────────────────────────────────
 * ⚠️  SECURITY:
 *    - এই ফাইলটি .gitignore-এ আছে। NEVER commit করবেন না।
 *    - secrets.h.example থেকে copy করুন এবং নিজের values দিন।
 *
 * ══════════════════════════════════════════════════════════════════════════════
 * SETUP STEPS (v13 — Custom Token Auth):
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * STEP 1 — FIREBASE_HOST:
 *   Firebase Console → Realtime Database → Database URL copy করুন
 *   (https:// এবং trailing / ছাড়া)
 *   Example: yourproject-default-rtdb.firebaseio.com
 *
 * STEP 2 — FIREBASE_WEB_API_KEY:
 *   Firebase Console → Project Settings → General → Web API Key
 *   Example: AIzaSyAbc123XYZ...
 *
 * STEP 3 — DEVICE_REGISTRATION_SECRET:
 *   একটি strong random string — ESP32 ও Cloud Function দুটোতেই এটা লাগবে।
 *   Generate: openssl rand -hex 32
 *   তারপর Cloud Function-এ set করুন:
 *   firebase functions:secrets:set DEVICE_REGISTRATION_SECRET
 *   (same value দিন)
 *
 * STEP 4 — CLOUD_FUNCTIONS_BASE_URL:
 *   Firebase Console → Functions → onStatusChange এর URL দেখুন
 *   এর region/project part নিন।
 *   Example: https://us-central1-smartiot-8190a.cloudfunctions.net
 *
 * STEP 5 — Google Root CA:
 *   নিচেরটা ঠিক আছে। Expire: 2036-06-22
 *   Update: https://pki.goog/roots.pem
 *
 * NOTE: JWT_HMAC_SECRET আর লাগবে না — v13-এ Firebase Custom Token Auth ব্যবহার হয়।
 *
 **********************************************************************************/

#ifndef SECRETS_H
#define SECRETS_H

// ── Firebase Realtime Database Host ──────────────────────────────────────────
#define FIREBASE_HOST  "smartiot-8190a-default-rtdb.firebaseio.com"

// ── Firebase Web API Key (for Auth REST API) ──────────────────────────────────
// Firebase Console → Project Settings → General → Web API Key
#define FIREBASE_WEB_API_KEY  "YOUR_FIREBASE_WEB_API_KEY_HERE"

// ── Device Registration Secret ────────────────────────────────────────────────
// Must EXACTLY match the Firebase Secret: DEVICE_REGISTRATION_SECRET
// Set with: firebase functions:secrets:set DEVICE_REGISTRATION_SECRET
// Generate: openssl rand -hex 32
#define DEVICE_REGISTRATION_SECRET  "YOUR_DEVICE_REGISTRATION_SECRET_HERE"

// ── Cloud Functions Base URL ──────────────────────────────────────────────────
// Example: https://us-central1-YOUR_PROJECT_ID.cloudfunctions.net
#define CLOUD_FUNCTIONS_BASE_URL  "https://us-central1-smartiot-8190a.cloudfunctions.net"

// ── Google GTS Root R1 CA (for TLS to Firebase) ──────────────────────────────
// Valid until: 2036-06-22. Source: https://pki.goog/roots.pem
static const char GOOGLE_ROOT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIFVzCCAz+gAwIBAgINAgPlk28xsBNJiGuiFzANBgkqhkiG9w0BAQwFADBHMQsw
CQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExMQzEU
MBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMTYwNjIyMDAwMDAwWhcNMzYwNjIyMDAw
MDAwWjBHMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZp
Y2VzIExMQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQC2EQKLHuOhd5s73L+UPreVp0A8of2C+X0yBoJx9vamf/vo
narMfLv6ty5uV1pNdW6BFMK0Z24CN0R7HrG1U1mMCp4TYl2CX7SCU91Vlb+4OMLV
OFbHbWmzWISMnJthOHzVg9JW/8rQtIH0w2R5JMp9E0SPxGnJGN0dSFHwQYcFXYsb
kzwHvHv2pVYd+T6E7RG7ZkJPLhEDQ1C0rl3GVEtImjSyasESDoW6rqrv7nUi7Xhj
yVvhANc7eJEoMjOAbUzWCU3lL+vGbj7VNLQa2sVgM1GqMpZ2qVT8DBlAIJoERf3S
vCxsV3S5Sf2YtBkFIxMxSiQPJzPzZjHbwgBq9d8bNQNMqKqyYDKnAh3Kh1vDQFV
MRzKJaBRMqPV6FWMEbxMHOZX9hbSk7R0nKjCxEEF0JrVKKsqZCFbOL+xHB6oo2/N
mEy0PD2RQRH/nDr9HyBGTr0Zt4O0FwJCkJsPaRpGABK0nBMJK9K/aFZ6cMJeJBv
MZJQz9z5U0IUFsDxp0bGlMlDZ+fQ4VCOyNiGM5J2OkVQsPSotTJ6pxlRUNt+WNTT
KrMJi2lfVrLRY4NIBx5wCJOF2cHKSKv5QZwGfM2T8Dv/XNW+JR0TNh6b3AkjMGfJ
xHDCahLCFSoF4d9bk3VNdikBWgMqe0TuNJrG7OP4GRW7EidnXLkdklwFpwIDAQAB
o0IwQDAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU
5K8rJnEaK0gnhS9SZizv8IkTcT4wDQYJKoZIhvcNAQEMBQADggIBADiWCu49tJYe
X++dnAsznyvgyv3SjgofQXSlfKqE1OXyHuY3UjKcC9FhHb8owbZEKTV1d5iyfNm9
dKyKaOOpMQkpAWBz40d8U6iQSifvS9efk+eCNs6aaAyC58/UEBZvXw6ZXPYfcX3v
73svfuo21pdwCxXu11xWajOl40k4DLh9+42FpLFZXvRq4d2h9mREruZRgyFmxhE+
885H7pwoHyXa/6xmld01D1zvICxi/ZG6qc5ud1S4BNpOjeFori8Boku7p1ewMWBZa
H/r4Rb6e9L4q3BX6tF8RY8ytxkMxb0cvZ0tcA3sIAD0HCeKBuK0PKH0fKMQ1VIRf
H8BNQR9JAL7hR9aRFnXXnOSGYj+A4H3UCQASOaonQvW9BcGEaaBcMpSMzPQyBFzN
mCt06ERqOmYUvhV0K0F4f8vBjBFQ1cCYOA0JMCR1BPIK0h4v1iLNX/vIeIdZ03qT
wGEkpHVKYRmYgkBRGhW7n9bOuqoS9Soxd/7rnCnHWj0ZPHHkagpB2s7JV4RLHYNO
ePGFEGmEbT3P3ZS1doxBH3aHLnYHPCiavpSmBiRGV9JIBPXNPdE1q4QRmRqO3fXV
9+HLnMELVo3c9qrRF+0UdJV+2eTK9VjGAJr1F0sxCT9q6UHlQlk4t3yHbRv0JHKM
P6V3rEDLEjkT
-----END CERTIFICATE-----
)EOF";

#endif // SECRETS_H
