# SmartIoT — SMART WATER LEVEL CONTROL BD
### v13.0.0 PRODUCTION — Complete Package

**Company:** Smart IoT Interface  
**Developer:** Sobuj Billah (IoT Systems Architect)  
**Contact:** smartiotinterface@gmail.com | +8801680603444

---

## ফাইল স্ট্রাকচার

```
SmartIoT_FINAL/
├── esp32/
│   └── SmartIoT_v13/
│       ├── SmartIoT_v13.ino      ← ESP32 Firmware (v13.0.0)
│       └── secrets.h             ← আপনার credentials দিন (gitignored)
├── firebase/
│   ├── functions/
│   │   ├── index.js              ← Cloud Functions (3টি: getDeviceToken, onStatusChange, onUserDelete)
│   │   └── package.json
│   └── database.rules.json       ← Firebase RTDB Security Rules (v13 updated)
├── lib/                          ← Flutter App source
├── android/                      ← Android build
├── pubspec.yaml
└── ...
```

---

## v13 এ কী বদলেছে

### 1. ESP32 Firebase Authentication — সম্পূর্ণ নতুন (Critical Fix)
- আগে: ESP32 নিজে HS256 JWT বানাতো — Firebase accept করত না
- এখন: **Firebase Custom Token Auth**
  - ESP32 → `getDeviceToken` Cloud Function → Custom Token
  - Custom Token → Firebase Auth REST → ID Token + Refresh Token  
  - ID Token দিয়ে Firebase RTDB-তে write করে
  - 1 ঘণ্টা পরে Refresh Token দিয়ে নতুন ID Token নেয়

### 2. Cloud Functions — নতুন `getDeviceToken` function যোগ
### 3. database.rules.json — `auth.uid` (আগে ভুলভাবে `auth.token.sub` ছিল)
### 4. secrets.h — নতুন format (`FIREBASE_WEB_API_KEY`, `DEVICE_REGISTRATION_SECRET`, `CLOUD_FUNCTIONS_BASE_URL`)

---

## Setup করুন

### Step 1 — Firebase Setup
```bash
# Firebase project-এ login করুন
firebase login
firebase use smartiot-8190a  # আপনার project ID

# Device secret set করুন
firebase functions:secrets:set DEVICE_REGISTRATION_SECRET
# Prompt-এ একটা strong random value দিন, যেমন: openssl rand -hex 32

# Deploy করুন
firebase deploy --only functions
firebase deploy --only database
```

### Step 2 — ESP32 secrets.h পূরণ করুন
`esp32/SmartIoT_v13/secrets.h` খুলুন এবং পূরণ করুন:
```cpp
#define FIREBASE_HOST             "yourproject-default-rtdb.firebaseio.com"
#define FIREBASE_WEB_API_KEY      "AIzaSy..."  // Firebase Console → Project Settings → Web API Key
#define DEVICE_REGISTRATION_SECRET "..."       // Same value যা firebase functions:secrets:set-এ দিয়েছেন
#define CLOUD_FUNCTIONS_BASE_URL  "https://us-central1-yourproject.cloudfunctions.net"
```

### Step 3 — Arduino IDE তে Upload করুন
- Arduino IDE তে `SmartIoT_v13.ino` খুলুন
- Board: ESP32 Dev Module
- Upload করুন

### Step 4 — Flutter App Build করুন
```bash
flutter pub get
flutter run  # Debug
flutter build apk --release  # Production APK
```

---

## সিস্টেম Architecture

```
[ESP32]──BLE──[Flutter App]──Firebase Auth──[User]
   │                              │
   └──WiFi──[Firebase RTDB]──[Cloud Functions]──[FCM Push]
              ↑
   Custom Token Auth (v13)
   esp32-device-{deviceId}
```

---

## Hardware PIN Mapping

| GPIO | Function |
|------|----------|
| 4 | Float Sensor LOW (INPUT_PULLUP) |
| 15 | Float Sensor MID (INPUT_PULLUP) |
| 5 | Float Sensor FULL (INPUT_PULLUP) |
| 2 | Pump Relay (HIGH=ON) |
| 18 | Buzzer |
| 16 | LED WiFi |
| 17 | LED Pump |
| 23 | Button MODE |
| 25 | Button PUMP |
| 26 | Button MUTE |
| 0 | Factory Reset (hold 10s) |
| 21/22 | OLED SDA/SCL |
| 27/14 | Ultrasonic TRIG/ECHO |
| 33 | Sensor Mode Toggle |
| 34 | Emergency Wakeup |

